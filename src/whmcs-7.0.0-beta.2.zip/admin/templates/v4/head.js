$(document).ready(function(){
     $("#shownotes").click(function () {
        $("#mynotes").toggle("slow");
        return false;
    });
    $("#savenotes").click(function () {
        $("#mynotes").toggle("slow");
        $.post("index.php", $("#frmmynotes").serialize() );
    });
    $("#frmintellisearch").submit(function(e) {
        e.preventDefault();
        $.post("search.php", $("#frmintellisearch").serialize(),
        function(data){
            if (data) {
                $("#searchresults").html(data);
                $("#btnIntelliSearch").hide();
                $("#btnIntelliSearchCancel").removeClass('hidden').show();
                $("#searchresults").hide().removeClass('hidden').slideDown();
            }
        });
    });
    $(".datepick, .date-picker").datepicker({
        dateFormat: datepickerformat,
        showOn: "button",
        buttonImage: "images/showcalendar.gif",
        buttonImageOnly: true,
        showButtonPanel: true
    });
});
function intellisearchcancel() {
    $("#intellisearchval").val("");
    $("#btnIntelliSearchCancel").hide();
    $("#btnIntelliSearch").show();
    $("#searchresults").slideUp();
}
